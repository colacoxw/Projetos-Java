import javax.swing.JPanel;

public class Jogo extends JPanel {

	/**
	 * Create the panel.
	 */
	public Jogo() {

	}

}
